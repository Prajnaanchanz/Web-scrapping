import requests
from bs4 import BeautifulSoup
import pandas as pd

def scrape_books():
    base_url = "http://books.toscrape.com/catalogue/page-{}.html"
    book_data = []

    for page in range(1, 3):  # Scraping first 2 pages for the example
        url = base_url.format(page)
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        books = soup.find_all('article', class_='product_pod')
        for book in books:
            title = book.h3.a['title']
            price = book.find('p', class_='price_color').text
            availability = book.find('p', class_='instock availability').text.strip()

            book_data.append({
                'Title': title,
                'Price': price,
                'Availability': availability
            })

    df = pd.DataFrame(book_data)
    df.to_csv('books.csv', index=False)
    print("Scraping completed and data saved to books.csv")

# Run the scraper
scrape_books()



• In an open cycle OTEC, the sea water is itself used to generate heat without any kind of intermediate fluid.
• Open cycle OTEC uses the tropical oceans warm surface water to make electricity




SRINIVAS INSTITUTE OF TECHNOLOGY
DEPARTMENT OF ARTIFICAL INTELLIGENCE AND DATA SCIENCE 
// Ambiguity caused by erasure on
// overloaded methods.
class MyGenClass<T, V> {
T ob1;
V ob2;
// ...
// These two overloaded methods are ambiguous
// and will not compile.
void set(T o) {
ob1 = o;
}
void set(V o) {
ob2 = o;
}
}




Attempt to overload set() based on parameters of type T and V.

There is no requirement that T and V actually be different
types.

Example: MyGenClass<String, String> obj = new MyGenClass<String, String>().
Both T and V replaced by String, making both versions of set() identical.

The second and more fundamental problem is that the type erasure of set( ) reduces both versions to the following:
the overloading of set( ) as attempted in MyGenClass is inherently ambiguous

Both T and V are String, making it unclear which version of set() to call.

In the preceding example, it would be much better to use two separate method
names, rather than trying to overload set( ).

The solution to ambiguity involves the restructuring of the code, because ambiguity often means that you have a conceptual error in your design.